#define IDD_DIALOG_SPLIT                504
#define IDC_STATIC_SPLIT_PATH           1000
#define IDC_COMBO_SPLIT_PATH            1001
#define IDC_BUTTON_SPLIT_PATH           1002
#define IDC_STATIC_SPLIT_VOLUME         1010
#define IDC_COMBO_SPLIT_VOLUME          1011

