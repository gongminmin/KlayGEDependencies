#define IDD_ABOUT                       507
#define IDI_LOGO                        138
#define IDC_ABOUT_STATIC_REGISTER_INFO  1010
#define IDC_ABOUT_BUTTON_HOMEPAGE       1020
#define IDC_ABOUT_BUTTON_SUPPORT        1021
#define IDC_ABOUT_BUTTON_REGISTER       1022
