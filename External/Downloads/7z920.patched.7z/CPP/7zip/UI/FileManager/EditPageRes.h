#define IDD_EDIT                 542
#define IDD_EDIT_2               642

#define IDC_EDIT_STATIC_EDITOR  1000
#define IDC_EDIT_EDIT_EDITOR    1001
#define IDC_EDIT_BUTTON_EDITOR  1002

#define IDC_EDIT_STATIC_DIFF    1010
#define IDC_EDIT_EDIT_DIFF      1011
#define IDC_EDIT_BUTTON_DIFF    1012
