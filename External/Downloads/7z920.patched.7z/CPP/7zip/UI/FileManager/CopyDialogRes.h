#define IDD_DIALOG_COPY                506

#define IDC_COPY_STATIC                1000
#define IDC_COPY_COMBO                 1001
#define IDC_COPY_SET_PATH              1002
#define IDC_COPY_INFO                  1003

#define IDS_SET_FOLDER  210
