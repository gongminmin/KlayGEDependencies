#define IDD_DIALOG_BROWSE             509
#define IDC_BROWSE_LIST               1000
#define IDC_BROWSE_PATH               1001
#define IDC_BROWSE_PARENT             1002
