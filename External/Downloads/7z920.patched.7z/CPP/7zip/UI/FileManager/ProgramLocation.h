// ProgramLocation.h

#ifndef __PROGRAM_LOCATION_H
#define __PROGRAM_LOCATION_H

#include "Common/MyString.h"

bool GetProgramFolderPath(UString &folder); // normalized

#endif
