// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#include <windows.h>
#include <commctrl.h>
#include <shlobj.h>
#include <stdio.h>

#include "Common/NewHandler.h"

#endif
