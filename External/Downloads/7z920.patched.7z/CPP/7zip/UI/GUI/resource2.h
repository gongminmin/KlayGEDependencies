#define IDS_COMPRESSED_COLON            2277
#define IDS_ARCHIVES_COLON              2278
#define IDS_PROGRESS_COMPRESSING        98
