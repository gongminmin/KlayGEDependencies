//  (C) Copyright Beman Dawes 2000. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_ITERATOR_HPP
#define BOOST_ITERATOR_HPP

// This header is obsolete and will be deprecated.

#include <iterator>
#include <cstddef>           // std::ptrdiff_t

namespace boost
{

  template <class Category, class T,
    class Distance = std::ptrdiff_t,
    class Pointer = T*, class Reference = T&>
  struct iterator
  {
    typedef T         value_type;
    typedef Distance  difference_type;
    typedef Pointer   pointer;
    typedef Reference reference;
    typedef Category  iterator_category;
  };

} // namespace boost

#endif // BOOST_ITERATOR_HPP
